package com.cg.entities;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;



public class AdminLogin {
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Z][a-zA-Z]{3,15}",message="Name should contain letters only <br> and size should between 4 and 15 letters only")
	private String userName;
	
	
	@NotEmpty(message="Password is mandatory")
	//@Pattern(regexp="[A-Z][a-zA-Z]{3,15}",message="Password should contain letters only <br> and size should between 4 and 15 letters only")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public AdminLogin() {
		super();
	}
	public AdminLogin(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
}
