package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="TRAINEE")
public class Trainee {
		@Id
		@Column(name="TRAINEEID")
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
		@SequenceGenerator(name="seq",sequenceName="seq_trainee_id",allocationSize=1)
		private int traineeId;
		@Column(name="TRAINEENAME")
		private String traineeName;
		@Column(name="TRAINEEDOMAIN")
		private String traineeDomain;
		@Column(name="TRAINEELOCATION")
		private String traineeLocation;
		public int getTraineeId() {
			return traineeId;
		}
		public void setTraineeId(int traineeId) {
			this.traineeId = traineeId;
		}
		public String getTraineeName() {
			return traineeName;
		}
		public void setTraineeName(String traineeName) {
			this.traineeName = traineeName;
		}
		public String getTraineeDomain() {
			return traineeDomain;
		}
		public void setTraineeDomain(String traineeDomain) {
			this.traineeDomain = traineeDomain;
		}
		public String getTraineeLocation() {
			return traineeLocation;
		}
		public void setTraineeLocation(String traineeLocation) {
			this.traineeLocation = traineeLocation;
		}
		public Trainee(int traineeId, String traineeName, String traineeDomain,
				String traineeLocation) {
			super();
			this.traineeId = traineeId;
			this.traineeName = traineeName;
			this.traineeDomain = traineeDomain;
			this.traineeLocation = traineeLocation;
		}
		public Trainee() {
			super();
		}
		@Override
		public String toString() {
			return "Trainee [traineeId=" + traineeId + ", traineeName="
					+ traineeName + ", traineeDomain=" + traineeDomain
					+ ", traineeLocation=" + traineeLocation + "]";
		}
		
}
