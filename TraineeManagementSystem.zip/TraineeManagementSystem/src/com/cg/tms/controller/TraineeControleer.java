package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.AdminLogin;
import com.cg.entities.Trainee;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeControleer {
	@Autowired
	TraineeService tser;
	@RequestMapping("start")
	public String showHome(Model model)
	{
		 AdminLogin user=new AdminLogin();
		model.addAttribute("user",user);
		return "login";
	}
	
	@RequestMapping("login")
	public String validation(@Valid@ModelAttribute("user")AdminLogin user,
			BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("user", user);
			return "login";
		}
		else
		{
			if(user.getUserName().equals("Santhosh")&&user.getPassword().equals("Santosh1"))
			model.addAttribute("user",user);
			return "operations";
		}
	}
	@RequestMapping("retrieveTrainess")
	public String retrieveTrainess(Model model)
	{
		List<Trainee> rlist=tser.retrievAllTrainees();
		model.addAttribute("rlist",rlist);
		return "retrievetrainess";
	}
	@RequestMapping("add")
    public String showInsertPage(Model model){
        Trainee trainee=new Trainee();
        model.addAttribute("trainee",trainee);
        return "addtrainee";
    }
    @RequestMapping("addTrainee")
    public String inserttrainee(@Valid@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
        if(res.hasErrors()){
            model.addAttribute("trainee", trainee);
            return "addtrainee";
        }else{
            
            tser.addTrainee(trainee);
            model.addAttribute("trainee",trainee);
            return "success";

        }
    }
    @RequestMapping("delete")
    public String showDeletePage(Model model)
    	{
    		Trainee trainee=new Trainee();
    		model.addAttribute("trainee", trainee);
    		return "deletetrainee";
    	}
    @RequestMapping("deletetrainee")
    	public String deletetrainee(@Valid@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model)
    	{
    	if(res.hasErrors()){
            model.addAttribute("trainee", trainee);
            return "deletetrainee";
        }else{
            tser.deleteTrainee(trainee.getTraineeId());
            model.addAttribute("trainee",trainee);
            return "deletesuccess";

        }
    	
    	}
    }
    


