package com.cg.tms.dao;

import java.util.List;

import com.cg.entities.Trainee;



public interface TraineeDao {
	List<Trainee> retrievAllTrainees();
	void addTrainee(Trainee trainee);
	void deleteTrainee(int id);
}
