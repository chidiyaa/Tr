package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao {
	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<Trainee> retrievAllTrainees() {
		String jpql="SELECT t FROM Trainee t";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
		
	}

	@Override
	public void addTrainee(Trainee trainee) {
		em.persist(trainee);
		
	}

	@Override
	public void deleteTrainee(int id) {
		String jpql="DELETE FROM Trainee t WHERE t.traineeId =?";
		Query query=em.createQuery(jpql);
		 query.setParameter(1, id);
		int count=query.executeUpdate();


	}
		
	}


