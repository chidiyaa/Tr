package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Trainee;
import com.cg.tms.dao.TraineeDao;


@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao tdao;
	
	@Override
	public List<Trainee> retrievAllTrainees() {
		
		return tdao.retrievAllTrainees();
	}

	@Override
	public void addTrainee(Trainee trainee) {
		tdao.addTrainee(trainee);		
	}

	@Override
	public void deleteTrainee(int id) {
		tdao.deleteTrainee(id);
		
	}

}
