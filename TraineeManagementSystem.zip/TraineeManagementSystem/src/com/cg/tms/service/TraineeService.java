package com.cg.tms.service;

import java.util.List;

import com.cg.entities.Trainee;

public interface TraineeService {
	List<Trainee> retrievAllTrainees();
	void addTrainee(Trainee trainee);
	public void deleteTrainee(int id) ;
}
